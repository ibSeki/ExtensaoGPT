document.addEventListener("DOMContentLoaded", () => {
  const processButton = document.getElementById("process-button");
  const videoUrlInput = document.getElementById("video-url");
  const responseDiv = document.getElementById("response");
  const spinner = document.getElementById("spinner");
  const numTopicsSelect = document.getElementById("num-topicos");

  let pollTimer = null;
  let failCount = 0;

  function setLoading(isLoading) {
    spinner.style.display = isLoading ? "block" : "none";
    processButton.disabled = isLoading;
  }

  function renderTopics(topicsText) {
    const topicsArray = (topicsText || "")
      .split(/\d+\.\s+/)
      .filter(t => t.trim() !== "")
      .map((t, i) => `<li><strong>${i + 1}:</strong> ${t.trim()}</li>`);

    responseDiv.innerHTML = `<span class="success">Topics:</span><ul>${topicsArray.join("")}</ul>`;
  }

  function normalizeYouTubeUrl(url) {
    try {
      const u = new URL(url);
      if (u.hostname === "youtu.be") {
        const id = u.pathname.replace("/", "").trim();
        if (id) return `https://www.youtube.com/watch?v=${id}`;
      }
      if (u.hostname.includes("youtube.com")) {
        if (u.pathname === "/watch") {
          const v = u.searchParams.get("v");
          if (v) return `https://www.youtube.com/watch?v=${v}`;
        }
      }
      return null;
    } catch {
      return null;
    }
  }

  async function fetchWithTimeout(url, ms, options = {}) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), ms);
    try {
      const res = await fetch(url, {
        cache: "no-store",
        ...options,
        signal: controller.signal
      });
      return res;
    } finally {
      clearTimeout(id);
    }
  }

  async function pollJob(jobId) {
    try {
      const res = await fetchWithTimeout(`http://127.0.0.1:5000/status/${jobId}`, 8000);

      if (res.status === 404) {
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = null;
        chrome.storage.local.remove(["last_job_id"]);
        setLoading(false);
        responseDiv.innerHTML = `<span class="error">Job não encontrado. Clique em Processar novamente.</span>`;
        return;
      }

      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status} ${text}`);
      }

      const job = await res.json();
      failCount = 0;

      const p = job.progress ?? 0;
      const st = job.status ?? "unknown";
      const step = job.step ? ` (${job.step})` : "";
      responseDiv.innerHTML = `<span>Status: <strong>${st}</strong>${step} — ${p}%</span>`;

      if (st === "done") {
        setLoading(false);
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = null;
        chrome.storage.local.remove(["last_job_id"]);
        renderTopics(job.topics || "");
        return;
      }

      if (st === "error") {
        setLoading(false);
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = null;
        chrome.storage.local.remove(["last_job_id"]);
        responseDiv.innerHTML = `<span class="error">Erro: ${job.error || "Falha no processamento."}</span>`;
        return;
      }
    } catch {
      failCount += 1;

      if (failCount <= 5) {
        responseDiv.innerHTML = `<span class="error">Falha temporária ao consultar status. Tentando novamente... (${failCount}/5)</span>`;
        return;
      }

      if (pollTimer) clearInterval(pollTimer);
      pollTimer = null;
      setLoading(false);
      responseDiv.innerHTML = `<span class="error">Não foi possível consultar o status. Verifique se o Flask está rodando em http://127.0.0.1:5000.</span>`;
    }
  }

  chrome.storage.local.get(["last_job_id", "last_video_url", "last_num_topics"], (st) => {
    if (st.last_num_topics) numTopicsSelect.value = String(st.last_num_topics);

    if (st.last_job_id) {
      setLoading(true);
      pollJob(st.last_job_id);
      pollTimer = setInterval(() => pollJob(st.last_job_id), 2000);
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabUrl = tabs?.[0]?.url || "";
      const normalized = normalizeYouTubeUrl(tabUrl);

      if (normalized) {
        videoUrlInput.value = normalized;
        chrome.storage.local.set({ last_video_url: normalized });
      } else if (st.last_video_url) {
        videoUrlInput.value = st.last_video_url;
      }
    });
  });

  processButton.addEventListener("click", async () => {
    const rawUrl = videoUrlInput.value.trim();
    const normalized = normalizeYouTubeUrl(rawUrl);
    const videoUrl = normalized || rawUrl;
    const numTopicos = parseInt(numTopicsSelect.value, 10);

    responseDiv.textContent = "";
    setLoading(true);
    failCount = 0;

    chrome.storage.local.remove(["last_job_id"]);

    if (!normalized) {
      responseDiv.innerHTML = `<span class="error">Abra um vídeo do YouTube (watch) ou cole um link válido.</span>`;
      setLoading(false);
      return;
    }

    chrome.storage.local.set({
      last_video_url: videoUrl,
      last_num_topics: numTopicos
    });

    try {
      const response = await fetchWithTimeout("http://127.0.0.1:5000/process", 15000, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          video_url: videoUrl,
          num_topicos: numTopicos
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        setLoading(false);
        responseDiv.innerHTML = `<span class="error">Erro: ${errorData.error || `HTTP ${response.status}`}</span>`;
        return;
      }

      const data = await response.json();
      const jobId = data.job_id;

      chrome.storage.local.set({ last_job_id: jobId });

      await pollJob(jobId);
      if (pollTimer) clearInterval(pollTimer);
      pollTimer = setInterval(() => pollJob(jobId), 2000);

    } catch {
      setLoading(false);
      responseDiv.innerHTML = `<span class="error">Error connecting to the server.</span>`;
    }
  });
});