import openai
import os
import re
import httpx
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv


def _load_env():
    here = Path(__file__).resolve().parent
    for p in (here / ".env", here.parent / ".env"):
        if p.exists():
            load_dotenv(dotenv_path=p, override=True)
            return
    load_dotenv(override=True)


_load_env()
OPENAI_API_KEY = (os.getenv("OPENAI_API_KEY") or "").strip()
BASE_PROMPT = (
    "Generate a concise summary by extracting the X most im- portant topics from the following text. "
    "Focus on highlighting important information that encapsulates the main points of the content."
)


def _make_client():
    timeout = httpx.Timeout(600.0, connect=30.0, read=600.0, write=600.0)
    return openai.OpenAI(
        api_key=OPENAI_API_KEY,
        timeout=timeout,
        max_retries=int(os.getenv("OPENAI_MAX_RETRIES", "6")),
    )


def _chunk_text(text: str, max_chars: int = 12000):
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    chunks, buf = [], ""
    for p in paragraphs:
        if len(buf) + len(p) + 1 > max_chars:
            if buf:
                chunks.append(buf)
                buf = ""
        buf += p + "\n"
    if buf:
        chunks.append(buf)
    return chunks


def _topics_for_chunk(client, chunk: str, k: int, model: str):
    prompt = BASE_PROMPT.replace("X", str(k)) + f"\n\n{chunk}"
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "You are an assistant specialized in summarizing educational content."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.2,
        max_tokens=220,
    )
    raw = response.choices[0].message.content.strip()
    lines = re.split(r"\n+|•\s*|-+\s*|\d+\.\s*", raw)
    topics = [l.strip(" -•\t") for l in lines if l.strip()]
    return topics[:k]


def extract_topics_with_gpt(transcription, num_topicos, workers=2):
    try:
        if not OPENAI_API_KEY:
            raise RuntimeError("OPENAI_API_KEY não encontrada.")

        workers = int(os.getenv("TOPICS_WORKERS", str(workers)))
        model = os.getenv("TOPICS_MODEL", "gpt-4")

        client = _make_client()
        chunks = _chunk_text(transcription, max_chars=12000)

        if len(chunks) == 1:
            prompt = BASE_PROMPT.replace("X", str(num_topicos)) + f"\n\n{transcription}"
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "You are an assistant specialized in summarizing educational content."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=320,
            )
            return response.choices[0].message.content.strip() if response.choices else None

        candidates = []
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_topics_for_chunk, client, c, num_topicos, model) for c in chunks]
            for fut in as_completed(futs):
                candidates.extend(fut.result())

        seen, unique = set(), []
        for t in candidates:
            key = t.lower()
            if key not in seen:
                seen.add(key)
                unique.append(t)

        candidates_text = "\n".join(f"- {t}" for t in unique)
        merge_prompt = BASE_PROMPT.replace("X", str(num_topicos)) + f"\n\n{candidates_text}"

        final_resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are an assistant specialized in summarizing educational content."},
                {"role": "user", "content": merge_prompt},
            ],
            temperature=0.2,
            max_tokens=320,
        )

        return final_resp.choices[0].message.content.strip() if final_resp.choices else None

    except Exception as e:
        print(f"Error processing topics with OpenAI GPT: {e}")
        return None