import openai
import os
import subprocess
import sys
import shutil
import httpx
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv
import time
import random


def _load_env():
    """
    Carrega .env de forma previsível:
    - tenta Back/.env
    - tenta raiz do projeto (../.env)
    - fallback: load_dotenv() padrão
    """
    here = Path(__file__).resolve().parent
    candidates = [here / ".env", here.parent / ".env"]
    for p in candidates:
        if p.exists():
            load_dotenv(dotenv_path=p, override=True)
            return str(p)
    load_dotenv(override=True)
    return None


_loaded = _load_env()
OPENAI_API_KEY = (os.getenv("OPENAI_API_KEY") or "").strip()

# ✅ Mantém seu default, mas permite sobrescrever por variável de ambiente
FFMPEG_PATH = os.getenv(
    "FFMPEG_PATH",
    r"C:\Users\IandeBarrosSeki-Date\OneDrive - COMPANHIA DPASCHOAL DE PARTICIPACOES\Documentos\ffmpeg-2025-11-24-git-c732564d2e-essentials_build\bin\ffmpeg.exe"
)


def _validate_api_key():
    # Não imprime a chave. Só valida formato mínimo.
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY não encontrada. Confira seu .env e reinicie o Flask.")
    if " " in OPENAI_API_KEY or "\t" in OPENAI_API_KEY or "\n" in OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY contém espaços/quebras de linha. Remova aspas/espaços no .env.")
    if not OPENAI_API_KEY.startswith("sk-"):
        raise RuntimeError("OPENAI_API_KEY parece inválida (não começa com 'sk-'). Confira se colou correto.")
    if OPENAI_API_KEY.startswith("sk--"):
        raise RuntimeError("OPENAI_API_KEY parece ter '--' a mais (ex.: 'sk--proj-...'). Corrija para 'sk-proj-...'.")


def _ensure_ffmpeg():
    """Verifica se o ffmpeg existe no caminho configurado."""
    if not os.path.exists(FFMPEG_PATH):
        raise FileNotFoundError(
            f"FFmpeg não encontrado em: {FFMPEG_PATH}. "
            "Verifique o caminho em transcricao.py (FFMPEG_PATH) ou defina FFMPEG_PATH no .env."
        )


def _yt_dlp_base_cmd():
    """
    Retorna o comando base do yt-dlp.
    Preferência:
    1) binário yt-dlp no PATH
    2) fallback: python -m yt_dlp (quando yt-dlp não está no PATH, mas instalado no venv)
    """
    if shutil.which("yt-dlp"):
        return ["yt-dlp"]
    return [sys.executable, "-m", "yt_dlp"]


def _run_cmd(cmd):
    """
    Executa comando capturando stdout/stderr para diagnóstico melhor.
    """
    return subprocess.run(
        cmd,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )


def download_audio_from_youtube(video_url):
    """
    Baixa apenas o áudio no melhor formato disponível, sem reencodar.

    Melhorias contra 403 (YouTube):
    - Tenta diferentes player_client via --extractor-args
    - (Opcional) tenta cookies do navegador se você definir YTDLP_COOKIES_FROM_BROWSER=chrome|firefox|edge
    """
    out_dir = Path("work")
    out_dir.mkdir(exist_ok=True)
    output_tmpl = str(out_dir / "audio.%(ext)s")

    base = (
        _yt_dlp_base_cmd()
        + [
            "-f", "bestaudio/best",
            "--no-playlist",
            "-o", output_tmpl,
            video_url
        ]
    )

    strategies = [
        ("player_client=default", base + ["--extractor-args", "youtube:player_client=default"]),
        ("default,-android_sdkless", base + ["--extractor-args", "youtube:player_client=default,-android_sdkless"]),
        ("player_client=web", base + ["--extractor-args", "youtube:player_client=web"]),
    ]

    cookies_browser = (os.getenv("YTDLP_COOKIES_FROM_BROWSER") or "").strip()
    if cookies_browser:
        strategies.append((
            f"cookies-from-browser={cookies_browser} + default",
            base + ["--cookies-from-browser", cookies_browser, "--extractor-args", "youtube:player_client=default"]
        ))

    last_error = None

    for label, cmd in strategies:
        try:
            print(f"🔽 yt-dlp tentativa: {label}")
            _run_cmd(cmd)
            audio_file = max(out_dir.glob("audio.*"), key=lambda p: p.stat().st_mtime)
            print("🔹 Audio successfully downloaded!")
            return str(audio_file)

        except subprocess.CalledProcessError as e:
            last_error = e
            stderr = (e.stderr or "")
            msg = stderr.strip().splitlines()[-6:]
            print("❌ Falhou:", label)
            if msg:
                print("   ↳ detalhes (stderr - últimas linhas):")
                for line in msg:
                    print("     ", line)
            continue

    print("❌ Error downloading audio: todas as tentativas falharam.")
    if last_error and last_error.stderr:
        tail = "\n".join(last_error.stderr.strip().splitlines()[-10:])
        print("   ↳ stderr final (tail):\n", tail)
    return None


def _split_audio_ffmpeg(file_path: str, segment_seconds: int = 120):
    """
    Divide o áudio em segmentos MP3 mono 16k.
    segment_seconds padrão = 120s (2min) para reduzir tamanho de upload.
    """
    _ensure_ffmpeg()

    file_path = Path(file_path)
    seg_dir = file_path.parent / "segments"

    # limpa pasta antiga
    if seg_dir.exists():
        try:
            shutil.rmtree(seg_dir)
        except Exception:
            pass
    seg_dir.mkdir(exist_ok=True)

    seg_tmpl_mp3 = str(seg_dir / "seg_%03d.mp3")

    cmd = [
        FFMPEG_PATH, "-hide_banner", "-loglevel", "error",
        "-i", str(file_path),
        "-vn",
        "-ac", "1",
        "-ar", "16000",
        "-f", "segment",
        "-segment_time", str(segment_seconds),
        "-reset_timestamps", "1",
        "-codec:a", "mp3",
        "-q:a", "7",
        seg_tmpl_mp3
    ]

    subprocess.run(cmd, check=True)

    segments = sorted(seg_dir.glob("seg_*.mp3"))
    if not segments:
        raise RuntimeError("FFmpeg não gerou segmentos de áudio.")
    return [str(p) for p in segments]


def _make_openai_client():
    timeout = httpx.Timeout(600.0, connect=30.0, read=600.0, write=600.0)
    return openai.OpenAI(
        api_key=OPENAI_API_KEY,
        timeout=timeout,
        max_retries=int(os.getenv("OPENAI_MAX_RETRIES", "6")),
    )


def _transcribe_one_segment(seg_path: str, max_retries: int = 6):
    """
    Transcreve 1 segmento com retry/backoff.
    ✅ Se for 401 (AuthenticationError), NÃO faz retry (falha rápido).
    """
    model_name = os.getenv("TRANSCRIBE_MODEL", "whisper-1")
    last_err = None

    for attempt in range(1, max_retries + 1):
        try:
            client = _make_openai_client()
            with open(seg_path, "rb") as audio_file:
                response = client.audio.transcriptions.create(
                    model=model_name,
                    file=audio_file
                )
            return response.text

        except openai.AuthenticationError as e:
            # 401: chave inválida -> não adianta tentar de novo
            raise RuntimeError(
                "401 AuthenticationError: OPENAI_API_KEY inválida. "
                "Gere uma chave nova e atualize o .env (sem aspas/espaços), depois reinicie o Flask."
            ) from e

        except Exception as e:
            last_err = e
            wait = min(30.0, (2 ** (attempt - 1)) + random.random())
            print(f"⚠️ Transcrição falhou ({attempt}/{max_retries}): {type(e).__name__}: {e!r} — retry em {wait:.1f}s")
            time.sleep(wait)

    raise last_err


def transcribe_audio(file_path, segment_seconds=120, workers=1):
    """
    Transcreve:
    - segmenta para MP3 mono 16k
    - padrão: 2min por segmento + 1 worker (mais estável)
    """
    try:
        _validate_api_key()

        segment_seconds = int(os.getenv("TRANSCRIBE_SEGMENT_SECONDS", str(segment_seconds)))
        workers = int(os.getenv("TRANSCRIBE_WORKERS", str(workers)))
        max_retries = int(os.getenv("TRANSCRIBE_MAX_RETRIES", "6"))

        segments = _split_audio_ffmpeg(file_path, segment_seconds=segment_seconds)

        if len(segments) == 1:
            print("✅ Transcription started (single segment)...")
            return _transcribe_one_segment(segments[0], max_retries=max_retries)

        print(f"✅ Transcribing {len(segments)} segments with workers={workers}...")

        if workers <= 1:
            texts = []
            for p in segments:
                texts.append(_transcribe_one_segment(p, max_retries=max_retries))
            print("✅ Transcription completed successfully!")
            return "\n".join(texts)

        texts = [None] * len(segments)
        with ThreadPoolExecutor(max_workers=workers) as ex:
            fut_map = {
                ex.submit(_transcribe_one_segment, p, max_retries): i
                for i, p in enumerate(segments)
            }
            for fut in as_completed(fut_map):
                i = fut_map[fut]
                texts[i] = fut.result()

        print("✅ Transcription completed successfully!")
        return "\n".join(texts)

    except Exception as e:
        print(f"❌ Error transcribing audio: {type(e).__name__}: {e!r}")
        return None


def delete_audio_file(file_path):
    """
    Best-effort cleanup no Windows (evita WinError 5).
    """
    p = Path(file_path)
    seg_dir = p.parent / "segments"

    for attempt in range(8):
        try:
            if seg_dir.exists():
                shutil.rmtree(seg_dir)
            break
        except PermissionError:
            time.sleep(0.35 * (attempt + 1))
        except Exception:
            break

    for attempt in range(8):
        try:
            if p.exists():
                p.unlink()
            break
        except PermissionError:
            time.sleep(0.35 * (attempt + 1))
        except Exception:
            break

    print(f"🗑 Cleanup concluído para {file_path}")