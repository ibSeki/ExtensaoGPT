from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os
import json
import hashlib
from uuid import uuid4
from datetime import datetime, timedelta, timezone
from threading import Lock
from concurrent.futures import ThreadPoolExecutor

from transcricao import download_audio_from_youtube, transcribe_audio, delete_audio_file
from topicos import extract_topics_with_gpt

load_dotenv()

if not os.getenv("OPENAI_API_KEY"):
    raise RuntimeError("OPENAI_API_KEY not found. Set it in your .env or as an environment variable.")

app = Flask(__name__)
CORS(app)

JOBS = {}
JOBS_LOCK = Lock()
EXECUTOR = ThreadPoolExecutor(max_workers=int(os.getenv("MAX_JOBS", "2")))

WORK_DIR = "work"
CACHE_DIR = os.path.join(WORK_DIR, "cache")
os.makedirs(CACHE_DIR, exist_ok=True)

JOBS_FILE = os.path.join(WORK_DIR, "jobs.json")


def _now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _load_jobs():
    global JOBS
    try:
        if os.path.exists(JOBS_FILE):
            with open(JOBS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    JOBS = data
    except Exception:
        JOBS = {}


def _save_jobs():
    try:
        tmp = JOBS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(JOBS, f, ensure_ascii=False, indent=2)
        os.replace(tmp, JOBS_FILE)
    except Exception:
        pass


def _job_set(job_id: str, **fields):
    with JOBS_LOCK:
        job = JOBS.get(job_id, {})
        job.update(fields)
        JOBS[job_id] = job
        _save_jobs()


def _job_get(job_id: str):
    with JOBS_LOCK:
        return JOBS.get(job_id)


def _cleanup_jobs(older_than_hours=24):
    cutoff = datetime.now(timezone.utc) - timedelta(hours=older_than_hours)
    with JOBS_LOCK:
        to_delete = []
        for jid, j in JOBS.items():
            created_raw = (j.get("created_at") or "").replace("Z", "+00:00")
            try:
                created = datetime.fromisoformat(created_raw)
            except Exception:
                created = datetime.now(timezone.utc)
            if created < cutoff:
                to_delete.append(jid)
        for jid in to_delete:
            del JOBS[jid]
        if to_delete:
            _save_jobs()


def _cache_key(video_url: str, num_topics: int) -> str:
    return hashlib.sha1(f"{video_url}|{num_topics}".encode("utf-8")).hexdigest()


def _cache_path(key: str) -> str:
    return os.path.join(CACHE_DIR, f"{key}.json")


def _save_cache(key: str, payload: dict):
    path = _cache_path(key)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def _load_cache(key: str):
    path = _cache_path(key)
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _run_pipeline(job_id: str, video_url: str, num_topics: int):
    audio_file = None
    try:
        _job_set(job_id, status="running", progress=5, updated_at=_now_iso())

        ck = _cache_key(video_url, num_topics)
        cached = _load_cache(ck)
        if cached and cached.get("topics"):
            _job_set(job_id, status="done", progress=100, topics=cached["topics"], updated_at=_now_iso())
            return

        _job_set(job_id, progress=10, step="downloading_audio", updated_at=_now_iso())
        audio_file = download_audio_from_youtube(video_url)
        if not audio_file:
            raise RuntimeError("Failed to download audio from YouTube.")

        _job_set(job_id, progress=35, step="transcribing", updated_at=_now_iso())
        transcription = transcribe_audio(audio_file)
        if not transcription:
            raise RuntimeError("Failed to transcribe the audio.")

        _job_set(job_id, progress=80, step="extracting_topics", updated_at=_now_iso())
        topics = extract_topics_with_gpt(transcription, num_topics)
        if not topics:
            raise RuntimeError("Failed to extract topics.")

        _save_cache(ck, {"video_url": video_url, "num_topics": num_topics, "topics": topics, "created_at": _now_iso()})
        _job_set(job_id, status="done", progress=100, topics=topics, step="done", updated_at=_now_iso())

    except Exception as e:
        _job_set(job_id, status="error", progress=100, error=str(e), updated_at=_now_iso())
    finally:
        if audio_file:
            delete_audio_file(audio_file)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"ok": True}), 200


@app.route("/process", methods=["POST"])
def process_video_async():
    _cleanup_jobs()
    data = request.get_json() or {}

    video_url = (data.get("video_url") or "").strip()
    num_topics_raw = data.get("num_topicos", 7)

    try:
        num_topics = int(num_topics_raw)
    except Exception:
        num_topics = 7

    if not video_url:
        return jsonify({"error": "Video URL not provided."}), 400

    job_id = str(uuid4())
    _job_set(
        job_id,
        status="queued",
        progress=0,
        video_url=video_url,
        num_topics=num_topics,
        created_at=_now_iso(),
        updated_at=_now_iso(),
    )

    EXECUTOR.submit(_run_pipeline, job_id, video_url, num_topics)
    return jsonify({"job_id": job_id, "status": "queued"}), 202


@app.route("/status/<job_id>", methods=["GET"])
def job_status(job_id):
    job = _job_get(job_id)
    if not job:
        return jsonify({"error": "job_id not found"}), 404
    return jsonify(job), 200


if __name__ == "__main__":
    _load_jobs()
    app.run(debug=True, use_reloader=False, threaded=True)